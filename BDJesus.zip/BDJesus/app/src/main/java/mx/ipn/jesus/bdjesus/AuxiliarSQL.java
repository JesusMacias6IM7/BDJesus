package mx.ipn.jesus.bdjesus;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Profesor on 08/02/2019.
 */

public class AuxiliarSQL extends SQLiteOpenHelper{

    String SQL_Tabla = "CREATE TABLE Reservacion ("
            + "_id INTEGER PRIMARY KEY AUTOINCREMENT, "
            +  "Nombre TEXT";

    public AuxiliarSQL(Context context, String DBName, SQLiteDatabase.CursorFactory factory, int version){
        super(context, DBName, factory, version);

    }

    @Override
    public void onCreate(SQLiteDatabase db){
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
